<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

use Auth;

use App\Sales;
use App\User;
use App\SalesCron;
use App\AdminSalesCron;




class TaskDaily extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'task:daily';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $currentdate=date('Y-m-d H:i:s');

        $users=User::all();
        foreach($users as $user){
$twosellers=DB::table('users')->where('ref_id',$user->seller_id)->get();
foreach($twosellers as $key=>$twosell){
    $sellerid1=$twosellers[0]->seller_id;
$sellerid2=$twosellers[1]->seller_id;
}

$sellerOnematch=User::latest()->where('seller_id',$sellerid1)->first();
$sellerTwomatch=User::latest()->where('seller_id',$sellerid2)->first();

            $sellerOne=SalesCron::latest()->where('seller_id',$sellerid1)->count();
            $sellerTwo=SalesCron::latest()->where('seller_id',$sellerid2)->count();
if($sellerOne==0 || $sellerTwo==0){

}
else{
if($sellerOne>$sellerTwo)
{

    
        $len=$sellerOne-$sellerTwo;

        if($len)

         {   for($i=1;$i<=$len;$i++){
                $matsels=DB::table('product_scron')->where('seller_id',$sellerid1)->take($len)->get();
                foreach($matsels as $matsel)
               { 
            $mats=SalesCron::latest()->where('id',$matsel->id)->where('seller_id',$matsel->seller_id)->first();
  
                $mats->status=0;
        $mats->save();
               }
            }
        }
        $sellerOnematch->matches+=1;
    $sellerOnematch->save();

    $sellerTwomatch->matches+=1;
    $sellerTwomatch->save(); 
    }

    
elseif($sellerOne<$sellerTwo)
{
    

        $lenw=$sellerTwo-$sellerOne;

        if($lenw)

         {   for($i=1;$i<=$len;$i++){
                $matsels=DB::table('product_scron')->where('seller_id',$sellerid2)->take($lenw)->get();
                foreach($matsels as $matsel)
               { 
            $mats=SalesCron::latest()->where('id',$matsel->id)->where('seller_id',$matsel->seller_id)->first();
  
                $mats->status=0;
        $mats->save();
               }
            }
        }
        $sellerOnematch->matches+=1;
    $sellerOnematch->save();

    $sellerTwomatch->matches+=1;
    $sellerTwomatch->save(); 
    }

        $statusone=SalesCron::latest()->where('status',1)->where('seller_id',$user->seller_id)->count();


       

        $statuszero=SalesCron::latest()->where('status',0)->get();
        foreach($statuszero as $stz){
        $cat=new AdminSalesCron();
        $cat->product_id = $stz->product_id;

        $cat->customer_name = $stz->customer_name;

        $cat->phone = $stz->phone;
        $cat->seller_id = $stz->seller_id;
        $cat->ref_id = $stz->ref_id;


        $cat->save();


        }

    }
    }

        $statuson=SalesCron::latest()->delete();

        $this->info('Successfully sent daily quote to everyone.');

    }
}
